Date		: 9/15/2016
Class		: CS4310
Assignment	: Assignment 2
Author(s)	: Alex Dekau

Command to run	: python Tester.py

The source code for each of the data structures are in DataStructures.py
A tester script that proves they work is made in Tester.py. It imports DataStructures.py.

Notes about the code:
--------------------
- The for loops in the List data structure were tough to convert directly to python from the psuedocode. I ended up having to do some tricks to get them to conform to python's "for i in range(start, finish)" structure.
