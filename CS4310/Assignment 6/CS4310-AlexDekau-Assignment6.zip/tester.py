from quicksort import *
from mergesort import *

test = [99,14,17,2,8,19,52,36,100]
print "Test array: " + str(test)
print "Mergesort: " + str(mergesort(test))
print "Quicksort: " + str(quicksort(test))
